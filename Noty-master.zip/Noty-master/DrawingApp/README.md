# SimpleDrawingApp
Simple Drawing App written in Swift 3 and Xcode 8.
Simple Drawing App written in Swift 3 and Xcode 8.

Please go to your corresponding branch to retrieve the neccesary resources file for your needs. 
Check out my Youtube channel(BR Studio - Coding) for more information: https://www.youtube.com/channel/UClmRwdRb2PC6D3gJM-fpYUw

#Progress and Features
<img width="374" alt="screen shot 2016-09-21 at 7 06 41 pm" src="https://cloud.githubusercontent.com/assets/19306879/18708656/9486ca1a-802e-11e6-82a3-e5a692bb8c60.png">

- Implemented a neat user interface,added reset functionality and some simple colour presets.
- Simple and primitive drawing
- Make a paintbrush follow the user's hand as they draw,allowing for greater interaction)
- Make an eraser do the same thing provided they have chosen the eraser tool.
- Erase parts of your drawing
- Save your artwork into your photos
- Set Up the user interface for the Settings View Controller with Auto Layout.
- (NEW) Create a settings view controller to add more customization(such as change brush size,colours etc.)


#TODO
- Share your image via Facebook using Social Framework or UIActivityViewController

