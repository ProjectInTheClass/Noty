//
//  DiaryUnit.swift
//  NotyApp
//
//  Created by CAUAD20 on 2018. 7. 26..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//
// 다이어리,플래너,여행일기 모델 클래스

import Foundation


class Diary {
    var diaryTitle:String!
    var diaryDate:Int!
    var diaryContent:String!
    //var diaryImage:UIImage!
    
    init(diaryTitle:String!, diaryDate:Int!, diaryContent:String!){
        
        self.diaryTitle = diaryTitle
        self.diaryDate = diaryDate
        self.diaryContent = diaryContent

    }
}

/*
class StudyPlanner: Diary {
    var plannerSubject:String!
    var plannerTodolist:String!
    var plannerMembers:Int!
    
    init(plannerSubject:String!, plannerTodolist:String!,
         plannerMembers:Int!){
        
        self.plannerSubject = plannerSubject
        self.plannerTodolist = plannerTodolist
        self.plannerMembers = plannerMembers
        super.init(diaryTitle: "", diaryDate: 0, diaryContent: "")
    }
}

class Travel: Diary {
    var travelPlace:String!
    var travelRoute:String!
    var travelCost:Double!
    //var travelVideo?

    init(travelPlace:String!, travelRoute:String!, travelCost:Double!) {
        
        self.travelPlace = travelPlace
        self.travelRoute = travelRoute
        self.travelCost = travelCost
        super.init(diaryTitle: "", diaryDate: 0, diaryContent: "")
    }
}
*/

