//
//  ViewController.swift
//  NotyApp
//
//  Created by CAUAD20 on 2018. 7. 26..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//
// 첫 앱 실행 시 가이드 페이지 PageViewController
// http://www.seemuapps.com/page-view-controller-tutorial-with-page-dots

import UIKit

class PageViewController: UIPageViewController, UIPageViewControllerDelegate, UIPageViewControllerDataSource {

    //가이드 페이지 총 3장, 이 함수는 3개의 가이드 페이지 뷰를 호출하기 위한 함수
    func newViewController(viewController: String) -> UIViewController {
        return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: viewController)
    }
    
    //3개의 가이드 페이지 뷰컨트롤러의 배열, identifiers는 순서대로 [page1, page2, page3]
    lazy var orderedViewControllers: [UIViewController] = {
        return [self.newViewController(viewController: "page1"),
                self.newViewController(viewController: "page2"),
                self.newViewController(viewController: "page3")]
    } ()
    
    //Data source 함수들
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        let previousIndex = viewControllerIndex - 1
        
        //유저는 첫번째 뷰컨트롤러에서 시작하여 왼쪽으로 swipe하여 마지막 뷰컨트롤러에 도달
        guard previousIndex >= 0 else {
            return self.orderedViewControllers.last
        }
        
        guard orderedViewControllers.count > previousIndex else {
            return nil
        }
        
        return orderedViewControllers[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        let nextIndex = viewControllerIndex + 1
        let orderedViewControllersCount = orderedViewControllers.count
        
        //유저가 마지막 페이지 컨트롤러에 도착, 오른쪽으로 swipe하면 처음 페이지로 돌아갈 수 있음.
        guard orderedViewControllersCount != nextIndex else {
            return orderedViewControllers.first
        }
        
        guard orderedViewControllersCount > nextIndex else {
            return nil
        }
        
        return orderedViewControllers[nextIndex]
    }
    
    
    //adding the page control dot indicators
    var pageControl = UIPageControl()
    
    func configurePageControl() {
        pageControl = UIPageControl(frame: CGRect(x: 0, y: UIScreen.main.bounds.maxY - 50, width: UIScreen.main.bounds.width, height: 50))
        self.pageControl.numberOfPages = orderedViewControllers.count
        self.pageControl.currentPage = 0
        self.pageControl.tintColor = UIColor.black
        self.pageControl.pageIndicatorTintColor = UIColor.white
        self.pageControl.currentPageIndicatorTintColor = UIColor.black
        self.view.addSubview(pageControl)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.dataSource = self
        //화면이 로딩되고 나면 나타날 초기값
        if let firstViewController = orderedViewControllers.first {
            setViewControllers([firstViewController], direction: .forward, animated: true, completion: nil)
        
        //for pageControl dot indicators
        self.delegate = self
        configurePageControl()
            
            func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool,
                                    previousViewControllers: [UIViewController], transitionCompleted completed: Bool){
                let pageContentViewController = pageViewController.viewControllers![0]
                self.pageControl.currentPage = orderedViewControllers.index(of: pageContentViewController)!
            }
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
