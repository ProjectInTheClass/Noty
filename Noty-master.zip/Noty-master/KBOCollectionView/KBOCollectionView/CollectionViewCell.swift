//
//  CollectionViewCell.swift
//  KBOCollectionView
//
//  Created by Taehyeon Kim on 2017. 11. 13..
//  Copyright © 2017년 Taehyeon Kim. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    var hitter:Diary? { didSet {
        self.profileImageView?.image = hitter!.coverImage
        self.nameLabel?.text = hitter!.name
        //self.emblemImageView?.image = hitter!.team.emblem
        //self.averageLabel.text = String(hitter!.average)
        }}
    
    
    @IBOutlet weak var nameLabel: UILabel?
    @IBOutlet weak var profileImageView: UIImageView?
    
    @IBOutlet weak var averageLabel: UILabel!
    @IBOutlet weak var emblemImageView: UIImageView?
    
    
    

}
