//
//  CollectionViewController.swift
//  KBOCollectionView
//
//  Created by Taehyeon Kim on 2017. 11. 13..
//  Copyright © 2017년 Taehyeon Kim. All rights reserved.
//

import UIKit

struct Diary {
    let name:String
    let type:DiaryType

    var coverImageName:String?
    
    var coverImage:UIImage? { get{
        if let _profileImage = self.coverImageName {
            return UIImage(named:_profileImage)!
        } else {
            return nil
        }
        
        }}
}

enum DiaryType {
    case monthlyDiary
    case yearlyDiary
    case travelDiary
    
    /*
     var emblem:UIImage? { get{ //Enum은 Stored Property를 가질 수 없지만 Computed Property는 가질 수 있다.
        switch self {
        case .monthlyDiary:
            return UIImage(named:"haetae_tigers")!
        default:
            return nil
        }
        }}
 
     */
    
}

class CollectionViewController: UICollectionViewController {
    func dummyData() -> [Diary] {
        let diary01 = Diary(name: "2018다이어리", type:.yearlyDiary,coverImageName:"cover03")
        let diary02 = Diary(name: "7월_앱개발", type:.monthlyDiary,coverImageName:"cover01")
        let diary03 = Diary(name: "미국여행", type:.travelDiary, coverImageName:"cover04")
        let diary04 = Diary(name: "중국여행", type:.travelDiary, coverImageName:nil)
        let diary05 = Diary(name: "일본여행", type:.travelDiary,coverImageName:nil)
        
        return [diary01, diary02, diary03, diary04, diary05]
        
        //앞으로 해야할 부분 : 추가버튼 누른 후, 다이어리 종류 골라서 dummydata안에 하나씩 넣을 수 있게
        //사용자가 이름 바꿀수 있게 수정버튼 누르면 라벨에서 텍스트 입력창으로 넘어갔다가 이름 변경 후, 다시 저장
    }
    
    var kboHallOfFame:[Diary] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        kboHallOfFame = dummyData()
            //.sorted(by: {$0.year > $1.year})

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return kboHallOfFame.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath) as! CollectionViewCell
        let currentHitter = kboHallOfFame[indexPath.item]

        // Configure the cell
        cell.hitter = currentHitter

        
        
        return cell
    }

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
