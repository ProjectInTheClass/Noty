//
//  DataCenter.swift
//  Noty
//
//  Created by CAUAD20 on 2018. 8. 6..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//

import Foundation
import UIKit


struct Diary {
    let name:String
    let type:DiaryType
    var coverImageName:String?
    var coverImage:UIImage? {  get {
        //파라미터 이름을 언더바로 지정하면 함수 호출 시 이름을 생략할 수 있다
        if let _diaryImage = self.coverImageName {
            return UIImage(named: _diaryImage)
        } else {
            return nil
        }
        
        }}
}

enum DiaryType {
    case monthlyDiary
    case yearlyDiary
    case travelDiary
    
    /*
     var emblem:UIImage? { get{ //Enum은 Stored Property를 가질 수 없지만 Computed Property는 가질 수 있다.
     switch self {
     case .monthlyDiary:
     return UIImage(named:"haetae_tigers")!
     default:
     return nil
     }
     }}
     
     */
}
