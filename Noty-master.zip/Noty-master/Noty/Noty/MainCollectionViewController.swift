//
//  MainCollectionViewController.swift
//  Noty
//
//  Created by CAUAD20 on 2018. 8. 6..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//

import UIKit

private let reuseIdentidier = "Cell"

class CollectionViewCell: UICollectionViewCell {
    
    var diaryCell:Diary? { didSet {
        self.diaryImageView?.image = diaryCell!.coverImage
        self.diaryNameLabel?.text = diaryCell!.name
        
        //self.emblemImageView?.image = hitter!.team.emblem
        //self.averageLabel.text = String(hitter!.average)
        }}
    
    
    @IBOutlet weak var diaryImageView: UIImageView?
    @IBOutlet weak var diaryNameLabel: UILabel?
    
    
    @IBOutlet weak var averageLabel: UILabel!
    @IBOutlet weak var emblemImageView: UIImageView?
    
    /*
     @IBOutlet weak var nameLabel: UILabel?
     @IBOutlet weak var profileImageView: UIImageView?
     
     @IBOutlet weak var averageLabel: UILabel!
     @IBOutlet weak var emblemImageView: UIImageView?
     */
    
    
    
}





class MainCollectionViewController: UICollectionViewController {

    
    func dummyData() -> [Diary] {
        let diary01 = Diary(name: "2018다이어리", type:.yearlyDiary, coverImageName:"cover03")
        let diary02 = Diary(name: "7월_앱개발", type:.monthlyDiary, coverImageName:"cover01")
        let diary03 = Diary(name: "미국여행", type:.travelDiary, coverImageName:"cover04")
        let diary04 = Diary(name: "중국여행", type:.travelDiary, coverImageName:nil)
        let diary05 = Diary(name: "일본여행", type:.travelDiary, coverImageName:nil)
        
        return [diary01, diary02, diary03, diary04, diary05]
        
        
        //앞으로 해야할 부분 : 추가버튼 누른 후, 다이어리 종류 골라서 dummydata안에 하나씩 넣을 수 있게
        //사용자가 이름 바꿀수 있게 수정버튼 누르면 라벨에서 텍스트 입력창으로 넘어갔다가 이름 변경 후, 다시 저장
    }
    
    var diaryExample:[Diary] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Register cell classes
        diaryExample = dummyData()

        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let paintingViewController = segue.destination as? PaintingViewController
        
        let selectedIndexPath = self.collectionView?.indexPathsForSelectedItems
     
     // Get the new view controller using [segue destinationViewController].
     // Pass the selected object to the new view controller.
 
     }
 */
    
    
    // MARK: UICollectionViewDataSource
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return diaryExample.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCell
        let currentDiary = diaryExample[indexPath.item]
        
        
        
        // Configure the cell
        cell.diaryCell = currentDiary
        
        
        
        return cell
    }
    
    // MARK: UICollectionViewDelegate
    
    /*
     // Uncomment this method to specify if the specified item should be highlighted during tracking
     override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
     return true
     }
     */
    
    /*
     // Uncomment this method to specify if the specified item should be selected
     override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
     return true
     }
     */
    
    /*
     // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
     override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
     return false
     }
     
     override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
     return false
     }
     
     override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
     
     }
     */
    
}
