//
//  ProductCollectionViewCell.swift
//  GravitySliderExample
//
//  Created by Artem Tevosyan on 9/27/17.
//  Copyright © 2017 Artem Tevosyan. All rights reserved.
//

import UIKit

class ProductCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var newLabel: UILabel!
    @IBOutlet weak var productImage: UIImageView!
}
