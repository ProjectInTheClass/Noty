//
//  ViewController2.swift
//  GravitySliderFlowLayout_Example
//
//  Created by CAUAD19 on 2018. 8. 2..
//  Copyright © 2018년 CocoaPods. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    @IBOutlet weak var priceButton1: UIButton!
    @IBOutlet weak var pageControl2: UIPageControl!
    @IBOutlet weak var collectionView2: UICollectionView!
    
    
    
    @IBOutlet weak var productSubtitleLabel2: UILabel!
    
    
    
    @IBOutlet weak var productTitleLabel2: UILabel!
    
    let images = [#imageLiteral(resourceName: "Image"), #imageLiteral(resourceName: "Image-1"), #imageLiteral(resourceName: "Image-2"),]
    let titles = ["속지1 이름", "속지2 이름", "속지3 이름"]
    let subtitles = ["속지1 설명", "속지2 설명", "속지3 설명"]
    let prices = ["속지1 선택", "속지2 선택", "속지3 선택"]
    
    let collectionViewCellHeightCoefficient: CGFloat = 0.85
    let collectionViewCellWidthCoefficient: CGFloat = 0.55
    let priceButtonCornerRadius: CGFloat = 10
    let gradientFirstColor = UIColor(hex: "ff8181").cgColor
    let gradientSecondColor = UIColor(hex: "a81382").cgColor
    let cellsShadowColor = UIColor(hex: "2a002a").cgColor
    let productCellIdentifier = "ProductCollectionViewCell"
    
    private var itemsNumber = 1000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureCollectionView()
        configurePriceButton()
    }
    
    private func configureCollectionView() {
        let gravitySliderLayout = GravitySliderFlowLayout(with: CGSize(width: collectionView2.frame.size.height * collectionViewCellWidthCoefficient, height: collectionView2.frame.size.height * collectionViewCellHeightCoefficient))
        collectionView2.collectionViewLayout = gravitySliderLayout
        collectionView2.dataSource = self
        collectionView2.delegate = self
    }
    
    private func configurePriceButton() {
        priceButton1.layer.cornerRadius = priceButtonCornerRadius
    }
    
    private func configureProductCell(_ cell: ProductCollectionViewCell, for indexPath: IndexPath) {
        cell.clipsToBounds = false
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = cell.bounds
        gradientLayer.colors = [gradientFirstColor, gradientSecondColor]
        gradientLayer.cornerRadius = 21
        gradientLayer.masksToBounds = true
        cell.layer.insertSublayer(gradientLayer, at: 0)
        
        cell.layer.shadowColor = cellsShadowColor
        cell.layer.shadowOpacity = 0.2
        cell.layer.shadowRadius = 20
        cell.layer.shadowOffset = CGSize(width: 0.0, height: 30)
        
        cell.productImage.image = images[indexPath.row % images.count]
        
        cell.newLabel.layer.cornerRadius = 8
        cell.newLabel.clipsToBounds = true
        cell.newLabel.layer.borderColor = UIColor.white.cgColor
        cell.newLabel.layer.borderWidth = 1.0
    }
    
    private func animateChangingTitle(for indexPath: IndexPath) {
        UIView.transition(with: productTitleLabel2, duration: 0.3, options: .transitionCrossDissolve, animations: {
            self.productTitleLabel2.text = self.titles[indexPath.row % self.titles.count]
        }, completion: nil)
        UIView.transition(with: productSubtitleLabel2, duration: 0.3, options: .transitionCrossDissolve, animations: {
            self.productSubtitleLabel2.text = self.subtitles[indexPath.row % self.subtitles.count]
        }, completion: nil)
        UIView.transition(with: priceButton1, duration: 0.3, options: .transitionCrossDissolve, animations: {
            self.priceButton1.setTitle(self.prices[indexPath.row % self.prices.count], for: .normal)
        }, completion: nil)
    }
    
    @IBAction func didPressPriceButton(_ sender: Any) {
        
    }
    
}

extension ViewController2: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemsNumber
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: productCellIdentifier, for: indexPath) as! ProductCollectionViewCell
        self.configureProductCell(cell, for: indexPath)
        return cell
    }
    
    
}

extension ViewController2: UICollectionViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let locationFirst = CGPoint(x: collectionView2.center.x + scrollView.contentOffset.x, y: collectionView2.center.y + scrollView.contentOffset.y)
        let locationSecond = CGPoint(x: collectionView2.center.x + scrollView.contentOffset.x + 20, y: collectionView2.center.y + scrollView.contentOffset.y)
        let locationThird = CGPoint(x: collectionView2.center.x + scrollView.contentOffset.x - 20, y: collectionView2.center.y + scrollView.contentOffset.y)
        
        if let indexPathFirst = collectionView2.indexPathForItem(at: locationFirst), let indexPathSecond = collectionView2.indexPathForItem(at: locationSecond), let indexPathThird = collectionView2.indexPathForItem(at: locationThird), indexPathFirst.row == indexPathSecond.row && indexPathSecond.row == indexPathThird.row && indexPathFirst.row != pageControl2.currentPage {
            pageControl2.currentPage = indexPathFirst.row % images.count
            self.animateChangingTitle(for: indexPathFirst)
        }
    }
}
