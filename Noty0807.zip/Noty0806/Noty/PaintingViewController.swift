//
//  PaintingViewController.swift
//  Noty
//
//  Created by CAUAD20 on 2018. 8. 6..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//

import UIKit

class PaintingViewController: UIViewController {
    
    
    @IBOutlet weak var pencilIcon: UIBarButtonItem!
    @IBOutlet weak var eraserIcon: UIBarButtonItem!
    @IBOutlet weak var lassoIcon: UIBarButtonItem!
    @IBOutlet weak var stickerIcon: UIBarButtonItem!
    @IBOutlet weak var tapeIcon: UIBarButtonItem!
    
    @IBOutlet weak var InlayImage: UIImageView!
    
    
    var lastPoint = CGPoint.zero
    var swiped = false
    
    var red:CGFloat = 0.0
    var green:CGFloat = 0.0
    var blue:CGFloat = 0.0
    var brushSize:CGFloat = 5.0
    var opacityValue:CGFloat = 1.0
    
    var tool:UIImageView!
    var isDrawing = true
    
    @IBAction func pencilFunc(_ sender: Any) {
        
        func drawLines(fromPoint:CGPoint,toPoint:CGPoint) {
            UIGraphicsBeginImageContext(self.view.frame.size)
            InlayImage.image?.draw(in: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
            let context = UIGraphicsGetCurrentContext()
            
            context?.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y))
            context?.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y))
            tool.center = toPoint
            
            context?.setBlendMode(CGBlendMode.normal)
            context?.setLineCap(CGLineCap.round)
            context?.setLineWidth(brushSize)
            context?.setStrokeColor(UIColor(red: red, green: green, blue: blue, alpha: opacityValue).cgColor)
            
            context?.strokePath()
            
            InlayImage.image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
        }
        
        func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            swiped = false
            if let touch = touches.first {
                lastPoint = touch.location(in: self.view)
            }
        }
        
       func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
            swiped = true
            
            if let touch = touches.first {
                let currentPoint = touch.location(in: self.view)
                drawLines(fromPoint: lastPoint, toPoint: currentPoint)
                
                lastPoint = currentPoint
            }
        }
        
        func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
            if !swiped {
                drawLines(fromPoint: lastPoint, toPoint: lastPoint)
            }
        }
        
        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tool = UIImageView()
        tool.frame = CGRect(x: self.view.bounds.size.width, y: self.view.bounds.size.height, width: 38, height: 38)
        self.view.addSubview(tool)
        
    }
    
   

    
    @IBAction func eraserFunc(_ sender: Any) {
        
        if (isDrawing) {
            (red,green,blue) = (1,1,1)
           
            
        } else {
            (red,green,blue) = (0,0,0)
         
        }
        
        isDrawing = !isDrawing
    }
    
    
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}


