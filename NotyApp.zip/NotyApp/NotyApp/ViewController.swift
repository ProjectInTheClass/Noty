//
//  ViewController.swift
//  NotyApp
//
//  Created by CAUAD20 on 2018. 7. 26..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//
// 첫 앱 실행 시 가이드 페이지 PageViewController
// http://www.seemuapps.com/page-view-controller-tutorial-with-page-dots

import UIKit

class ViewController: UIPageViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
