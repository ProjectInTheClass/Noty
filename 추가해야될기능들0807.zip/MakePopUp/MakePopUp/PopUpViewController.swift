//
//  PopUpViewController.swift
//  MakePopUp
//
//  Created by CAUAD20 on 2018. 8. 7..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//

import UIKit

class PopUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //background 색상 설정
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //popup에서 close를 누르면 popup창을 닫는다
    @IBAction func closePopUp(_ sender: Any) {
        //self.view.removeFromSuperview(), 효과 필요없으면 그냥 이 코드 사용.
        self.removeAnimate()
    }
    
//popup창 show와 remove할 때 효과. 두 가지 함수를 위 close버튼 액션함수에 추가
    
    //popup창 뜨는 효과
    func showAnimate() {
        
        //view를 먼저 더 크게 변형
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        self.view.alpha = 0.0;
        //그리고 이 크기로 보여준다. (작은 상태에서 크게, 큰 상태에서 작게 보여주기 위한 효과인듯?)
        UIView.animate(withDuration: 0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        })
    }
    
    //popup창 사라지는 효과
    func removeAnimate() {
        
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
        }, completion: {
            (finished: Bool) in
            if (finished) { //만약 animate이 끝나면, popup창을 닫는다
                self.view.removeFromSuperview()
            }
        }
        )
        
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
