//
//  ViewController.swift
//  MakePopUp
//
//  Created by CAUAD20 on 2018. 8. 7..
//  Copyright © 2018년 CAUAD20. All rights reserved.
//

//https://www.youtube.com/watch?v=FgCIRMz_3dE
//기존의 view(ViewController)에서 popup(PopUpViewController)창을 띄운다

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //Show버튼을 누르면 PopUpView가 나온다
    @IBAction func showPopup(_ sender: Any) {
        
        //PopUpView의 identity inspector에서 스토리보드ID:sbPopUpID 확인하자
        let popOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "sbPopUpID") as! PopUpViewController
        
        //현재 창에서 추가할 popup창을 띄운다.
        self.addChildViewController(popOverVC)
        popOverVC.view.frame = self.view.frame
        self.view.addSubview(popOverVC.view)
        popOverVC.didMove(toParentViewController: self)
        
    }
    
}

