//
//  ProductCollectionViewCell.swift


import UIKit

class ProductCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var newLabel: UILabel!
    @IBOutlet weak var productImage: UIImageView!
}
